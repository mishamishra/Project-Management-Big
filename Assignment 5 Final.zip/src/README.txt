Old queries are almost the same with some slight modifications.
I made one Pair class in Project Management project. In User class, I made a pair object with <X,Y> as <User,UserReport>. So whenever a new User is created, I also create a userreport for that
user and store it in the pair. Whenever any job executes, I access it's userreport from it's users's pair and increase it's consumed.
For both user and project class, I created three new lists, one for unfinished jobs, one for finished jobs and third for all jobs.
To store users, I used a LinkedList. For projects, Trie. For jobs, Heap. For lowbudget jobs, RBTree(key=project name, value= list of jobs).
___________
timed_top_consumer: I iterated over the list of users and accessed their respective userreports. Userreports were added in a separate list in a sorted manner (whenever a new report is added 
to the list, I search for it's sorted position in the list straightaway by iterating through the list in the descending order).  In the end, top <top> userreports were returned.
BestCase TimeComplexity:  O(n) (when the sorted position of new userreport is at the end of the list always)
WorstCase TimeComplexity: O(n^2)  (when the sorted position of new userreport is at the beginning of the list always)    
{ where n is the number of users.}

new_user: I iterated over the all jobs list of the respected user and added all those jobs which met the respective criterion in an arraylist of type jobreport.
TimeComplexity: O(n)  {where n is the number of jobs of the given user}

new_project: I iterated over the all jobs list of the respected project and added all those which met the respective criterion in an arraylist of type jobreport.
TimeComplexity: O(n)  {where n is the number of jobs of the given project}

new_priority: I iterated over the arraylist of jobs in the maxheap and also traversed(inorder traversal) the RBtree and added all those jobs which met the respective criterion in an arraylist 
of type jobreport.
TimeComplexity: O(n + (mj)) {n= number of jobs in heap, m= number of nodes in RBtree, j= avg number of jobs per node}

new_project_user: First I searched that the given user and project exist or not. If yes, then I iterate over the finished jobs list of the given project and added all those jobs in a list which met 
the given criterion. Then I iterated over the all jobs list of the given project and added all those jobs in a list which met the given criterion.
Time Complexity: O(n) {where n is the number of jobs of the given project}

flush: I made two maxheap objects. Then I emptied the original maxheap of jobs by extracting elements one by one. If element met the given criterion, I add it to first maxheap otherwise to second
maxheap. then I put second maxheap equal to original maxheap. Then I executed all the jobs from the first maxheap and those which could not execute due to unsufficient budget, I again 
added them in the original maxheap.
TimeComplexity: O(nlogn) {n= number of elements in original maxheap at the starting.}




