package Trie;
import java.util.LinkedList;
public class Trie<T> implements TrieInterface<T> {
	TrieNode<T> root= new TrieNode<T>(null);
	TrieNode<T>[] array1=root.array;
	LinkedList<String> levels= new LinkedList<String>();
	public boolean emptyarray(TrieNode<T>[] array) {
		int i=0;
		while(i<array.length&&(array[i]==null||array[i].isDeleted)){
			i++;
		}
		if(i==array.length) {
			return true;
		}
		else {
			return false;
		}
	}
	public static String sort(String args) {
		String[] s1= args.split("");
		int l= s1.length;
		args="";
		int i =0;
		while(i<l) {
			String j= s1[i];
			int p= i;
			for(int x=i+1;x<l;x++) {
			if((s1[x].compareTo(j))<0) {
				j=s1[x];
				p=x;
				}
			}
			String temp;
			temp=s1[i];
			s1[i]=s1[p];
			s1[p]=temp;
			i++;
		}
		i=0;
		while(i<s1.length) {
			args+=(s1[i]+",");
			i++;
		}
		return args;
		}
    @Override
    public boolean delete(String word) {
    	TrieNode<T> node= search(word);
    	TrieNode<T> parent=null;
    	if(node==null) {
    		return false;
    	}
    	else {
    		node.EOW=false;
    		node.details=null;
    		if(emptyarray(node.array)==true) {
    			parent=node.parent;
    			node.isDeleted=true;
    		}
    		if(parent==null) {
    		}
    		else {
    		while(emptyarray(parent.array)==true) {
    			node=parent.parent;
    			parent.isDeleted=true;
    			parent.EOW=false;
    			parent=node;
    			if(parent==root) {
    				break;
    			}
    		}
    		}
    		return true;
    	}
    }

    @Override
    public TrieNode<T> search(String word) {
    	array1=root.array;
    	char[] arr= word.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		int index=(int) arr[i]-32;
    		if(array1[index]==null||array1[index].isDeleted==true) {
    			break;
    		}
    		if(array1[index]!=null) {
    				if(i==arr.length-1) {
    					if(array1[index].EOW==true) {
    						return array1[index];
            			}
            			else {
            				return null;
            			}
            			}
    				else {
    					i++;
    					array1= array1[index].array;
    				}
    				}
    		}
    	return null;
    	}

    @Override
    public TrieNode<T> startsWith(String prefix) {
    	array1=root.array;
    	char[] arr= prefix.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		int index=(int) arr[i]-32;
    		if(array1[index]==null||array1[index].isDeleted==true) {
    			break;
    		}
    		if(array1[index]!=null) {
    				if(i==arr.length-1) {
            				return array1[index];
            				}
    				else {
    					i++;
    					array1= array1[index].array;
    				}
    				}
    		}
    	return null;
    	}

    @Override
    public void printTrie(TrieNode trieNode) {
    	if(trieNode.EOW==true) {
    		System.out.println(trieNode.details);
    	}
    	int i=0;
    	while(i<95) {
    		if(trieNode.array[i]!=null) {
    			printTrie(trieNode.array[i]);
    		}
    		i++;
    	}
    	}

    @Override
    public boolean insert(String word, Object value) {
    	TrieNode<T> parent=root;
    	array1= root.array;
    	char[] arr= word.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		int index=(int) arr[i]-32;
    		if(array1[index]!=null) {
    			if(i==arr.length-1) {
        			if(array1[index].EOW==true) {
        				return false;
        			}
        			array1[index].details= (T) value;
        			i++;
        			array1[index].EOW= true;
        		}
    			else {
    			i++;
    			array1= array1[index].array;
    			}
    		}
    		else {
    			if(i==arr.length-1) {
        			array1[index]= new TrieNode<T>((T) value);
        			array1[index].parent= parent;
        			parent=array1[index];
        			i++;
        			array1[index].EOW=true;
        		}
    			else {
    				array1[index]= new TrieNode<T>(null);
    				array1[index].EOW=false;
    				array1[index].parent= parent;
    				parent=array1[index];
    				i++;
    				array1= array1[index].array;
    			}
    		}
    		
    		}
        return true;
    }
    public void level(int x, TrieNode<T>[] array) {
    	int i=0;
    	while(i<95) {
    		if(array[i]!=null&&!(array[i].isDeleted==true) ){
    			if(i+32!=32) {
    				if(levels.size()==x) {
    					levels.add(Character.toString((char) (i+32)));
    					if(emptyarray(array[i].array)==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,array[i].array);
    	    				i++;
    	    			}
    				}
    				else {
    					levels.set(x, levels.get(x)+Character.toString((char) (i+32)));
    					if(emptyarray(array[i].array)==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,array[i].array);
    	    				i++;
    	    			}
    				}
    				}
    			else {
    				if(levels.size()==x) {
    					levels.add("");
    					if(emptyarray(array[i].array)==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,array[i].array);
    	    				i++;
    	    			}
    				}
    				else {
    					if(emptyarray(array[i].array)==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,array[i].array);
    	    				i++;
    	    			}
    				}
    			}
    		}
    		else {
    			i++;
    		}
    	}
    	}

    @Override
    public void printLevel(int level) {
    	levels.clear();
    	level(0,root.array);
    	int i=0;
    	while(i<levels.size()){
    		levels.set(i,sort(levels.get(i)));
    		i++;
    		}
    	String str = levels.get(level-1);
    	System.out.println("Level"+ " "+level+":"+" "+str.substring(0, str.length() - 1));
    	}

    @Override
    public void print() {
    	System.out.println("-------------");
    	System.out.println("Printing Trie");
    	levels.clear();
    	level(0,root.array);
    	int i=0;
    	while(i<levels.size()) {
   		levels.set(i,sort(levels.get(i)));
    		i++;
    		}
    	i=0;
    	while(i<levels.size()) {
        	System.out.println("Level"+ " "+(i+1)+":"+" "+ levels.get(i).substring(0, levels.get(i).length() - 1));
        	i++;
    	}
    	System.out.println("Level"+ " "+(i+1)+":"+" ");
    	System.out.println("-------------");


    }
}
/*package Trie;
import java.util.LinkedList;
import java.util.Iterator;
public class Trie<T> implements TrieInterface<T> {
	TrieNode<T> root= new TrieNode<T>(null,' ');
	LinkedList<TrieNode<T>> list1=root.list;
	LinkedList<String> levels= new LinkedList<String>();
	
	public static String sort(String args) {
		String[] s1= args.split("");
		int l= s1.length;
		args="";
		int i =0;
		while(i<l) {
			String j= s1[i];
			int p= i;
			for(int x=i+1;x<l;x++) {
			if((s1[x].compareTo(j))<0) {
				j=s1[x];
				p=x;
				}
			}
			String temp;
			temp=s1[i];
			s1[i]=s1[p];
			s1[p]=temp;
			i++;
		}
		i=0;
		while(i<s1.length) {
			args+=(s1[i]+",");
			i++;
		}
		return args;
		}
    @Override
    public boolean delete(String word) {
    	TrieNode<T> node= search(word);
    	TrieNode<T> parent=null;
    	if(node==null) {
    		return false;
    	}
    	else {
    		node.EOW=false;
    		node.details=null;
    		if(node.list.isEmpty()==true) {
    			parent=node.parent;
    			parent.list.remove(node);
    		}
    		if(parent==null) {
    		}
    		else {
    		while(parent.list.isEmpty()==true) {
    			node=parent.parent;
    			node.list.remove(parent);
    			parent=node;
    			if(parent==root) {
    				break;
    			}
    		}
    		}
    		return true;
    	}
    }

    @Override
    public TrieNode<T> search(String word) {
    	list1=root.list;
    	char[] arr= word.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		boolean found=false;
    		Iterator<TrieNode<T>> itr= list1.iterator();
    		TrieNode<T> node=null;
    		while(itr.hasNext()) {
    			if((node=itr.next()).letter==arr[i]) {
    				found=true;
    				break;
    			}
    		}
    		if(found==false) {
    			break;
    		}
    		else {
    				if(i==arr.length-1) {
    					if(node.EOW==true) {
    						return node;
            			}
            			else {
            				return null;
            			}
            			}
    				else {
    					i++;
    					list1= node.list;
    				}
    				}
    		}
    	return null;
    	}

    @Override
    public TrieNode<T> startsWith(String prefix) {
    	list1=root.list;
    	char[] arr= prefix.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		boolean found=false;
    		Iterator<TrieNode<T>> itr= list1.iterator();
    		TrieNode<T> node=null;
    		while(itr.hasNext()) {
    			if((node=itr.next()).letter==arr[i]) {
    				found=true;
    				break;
    			}
    		}
    		if(found==false) {
    			break;
    		}
    		else{
    				if(i==arr.length-1) {
            				return node;
            				}
    				else {
    					i++;
    					list1= node.list;
    				}
    				}
    		}
    	return null;
    	}

    @Override
    public void printTrie(TrieNode trieNode) {
    	if(trieNode.EOW==true) {
    		System.out.println(trieNode.details);
    	}
    	int i=0;
    	while(i<trieNode.list.size()) {
    			printTrie((TrieNode) trieNode.list.get(i));
    		i++;
    	}
    	}

    @Override
    public boolean insert(String word, Object value) {
    	TrieNode<T> parent=root;
    	list1= root.list;
    	char[] arr= word.toCharArray();
    	int i=0;
    	while(i<arr.length) {
    		boolean found=false;
    		Iterator<TrieNode<T>> itr= list1.iterator();
    		TrieNode<T> node=null;
    		while(itr.hasNext()) {
    			if((node=itr.next()).letter==arr[i]) {
    			
    				found=true;
    				break;
    			}
    		}
    		if(found==true) {
    			if(i==arr.length-1) {
        			if(node.EOW==true) {
        				return false;
        			}
        			node.details= (T) value;
        			i++;
        			node.EOW= true;
        		}
    			else {
    			i++;
    			list1= node.list;
    			}
    		}
    		else {
    			if(i==arr.length-1) {
        			node= new TrieNode<T>((T) value, arr[i]);
        			list1.add(node);
        			node.parent= parent;
        			parent=node;
        			i++;
        			node.EOW=true;
        		}
    			else {
    				node= new TrieNode<T>(null,arr[i]);
    				list1.add(node);
    				node.EOW=false;
    				node.parent= parent;
    				parent=node;
    				i++;
    				list1= node.list;
    			}
    		}
    		
    		}
        return true;
    }
    public void level(int x, LinkedList<TrieNode<T>> array) {
    	int i=0;
    	while(i<array.size()) {
    			char letter=' ';
    			TrieNode<T> node=array.get(i);
    			if((letter=node.letter)!=' ') {
    				if(levels.size()==x) {
    					levels.add(Character.toString(letter));
    					if(node.list.isEmpty()==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,node.list);
    	    				i++;
    	    			}
    				}
    				else {
    					levels.set(x, levels.get(x)+Character.toString(letter));
    					if(node.list.isEmpty()==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,node.list);
    	    				i++;
    	    			}
    				}
    				}
    			else {
    				if(levels.size()==x) {
    					levels.add("");
    					if(node.list.isEmpty()==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,node.list);
    	    				i++;
    	    			}
    				}
    				else {
    					if(node.list.isEmpty()==true) {
    	    				i++;
    	    			}
    	    			else {
    	    				level(x+1,node.list);
    	    				i++;
    	    			}
    				}
    			}
    			}
    	}

    @Override
    public void printLevel(int level) {
    	levels.clear();
    	level(0,root.list);
    	int i=0;
    	while(i<levels.size()){
    		levels.set(i,sort(levels.get(i)));
    		i++;
    		}
    	String str = levels.get(level-1);
    	System.out.println("Level"+ " "+level+":"+" "+str.substring(0, str.length() - 1));
    	}

    @Override
    public void print() {
    	System.out.println("-------------");
    	System.out.println("Printing Trie");
    	levels.clear();
    	level(0,root.list);
    	int i=0;
    	while(i<levels.size()) {
   		levels.set(i,sort(levels.get(i)));
    		i++;
    		}
    	i=0;
    	while(i<levels.size()) {
        	System.out.println("Level"+ " "+(i+1)+":"+" "+ levels.get(i).substring(0, levels.get(i).length() - 1));
        	i++;
    	}
    	System.out.println("Level"+ " "+(i+1)+":"+" ");
    	System.out.println("-------------");

    }
}*/