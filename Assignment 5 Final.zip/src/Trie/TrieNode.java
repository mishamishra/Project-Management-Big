package Trie;
import Util.NodeInterface;
public class TrieNode<T> implements NodeInterface<T> {
	boolean isDeleted= false;
	TrieNode<T> parent;
	public boolean EOW;
	TrieNode<T>[] array= new TrieNode[95]; 
	public T details;
	TrieNode(T details) {
		EOW=false;
		for(int i=0;i<array.length;i++) {
			array[i]=null;
		}
		this.details=details;
		this.parent=null;
	}
    @Override
    public T getValue() {
        return details;
    }


}
/*package Trie;
import Util.NodeInterface;
import java.util.LinkedList;
public class TrieNode<T> implements NodeInterface<T> {
	char letter;
	TrieNode<T> parent;
	public boolean EOW;
	LinkedList<TrieNode<T>> list= new LinkedList<TrieNode<T>>(); 
	public T details;
	TrieNode(T details, char letter) {
		EOW=false;
		this.letter=letter;
		this.details=details;
		this.parent=null;
	}
    @Override
    public T getValue() {
        return details;
    }
    }*/