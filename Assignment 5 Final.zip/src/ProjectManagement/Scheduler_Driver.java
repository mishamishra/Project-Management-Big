package ProjectManagement;
import java.util.LinkedList;
import Trie.Trie;
import PriorityQueue.MaxHeap;
import RedBlack.RBTree;
import RedBlack.RedBlackNode;
import java.util.Iterator;
import Trie.TrieNode;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;

public class Scheduler_Driver extends Thread implements SchedulerInterface {
	int count=0;
	int globaltime=0;
	LinkedList<User> user= new LinkedList<User>();
	Trie<User> user1= new Trie<User>();
	Trie<Project> project= new Trie<Project>();
	MaxHeap<Job> job= new MaxHeap<Job>();
	Trie<Job> tempjob= new Trie<Job>();
	LinkedList<Job> finishedjobs= new LinkedList<Job>();
	RBTree<String,Job> projectjobs= new RBTree<String,Job>();
	ArrayList<JobReport_> tempreport= new ArrayList<JobReport_>();
	ArrayList<Job> unfinished= new ArrayList<Job>();
	public static void main(String[] args) throws IOException {
		Scheduler_Driver scheduler_driver = new Scheduler_Driver();
        File file;
        if (args.length == 0) {
            URL url = Scheduler_Driver.class.getResource("INP");
            file = new File(url.getPath());
        } else {
            file = new File(args[0]);
        }

        scheduler_driver.execute(file);
    }

    public void execute(File commandFile) throws IOException {
    	BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(commandFile));

            String st;
            while ((st = br.readLine()) != null) {
                String[] cmd = st.split(" ");
                if (cmd.length == 0) {
                    System.err.println("Error parsing: " + st);
                    return;
                }
                String project_name, user_name;
                Integer start_time, end_time;

                long qstart_time, qend_time;

                switch (cmd[0]) {
                    case "PROJECT":
                        handle_project(cmd);
                        break;
                    case "JOB":
                        handle_job(cmd);
                        break;
                    case "USER":
                        handle_user(cmd[1]);
                        break;
                    case "QUERY":
                        handle_query(cmd[1]);
                        break;
                    case "": // HANDLE EMPTY LINE
                        handle_empty_line();
                        break;
                    case "ADD":
                        handle_add(cmd);
                        break;
                    //--------- New Queries
                    case "NEW_PROJECT":
                    case "NEW_USER":
                    case "NEW_PROJECTUSER":
                    case "NEW_PRIORITY":
                        timed_report(cmd);
                        break;
                    case "NEW_TOP":
                        qstart_time = System.nanoTime();
                        timed_top_consumer(Integer.parseInt(cmd[1]));
                        qend_time = System.nanoTime();
                        System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                        break;
                    case "NEW_FLUSH":
                        qstart_time = System.nanoTime();
                        timed_flush( Integer.parseInt(cmd[1]));
                        qend_time = System.nanoTime();
                        System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                        break;
                    default:
                        System.err.println("Unknown command: " + cmd[0]);
                }

            }


            run_to_completion();
            print_stats();

        } catch (FileNotFoundException e) {
            System.err.println("Input file Not found. " + commandFile.getAbsolutePath());
        } catch (NullPointerException ne) {
            ne.printStackTrace();

        }
    }
    public void timed_handle_user(String name){
    	User obj= new User(name);
    	user.add(obj);
    	user1.insert(name, obj);
    	UserReport userreport= new UserReport(obj);
    	obj.pair= new Pair<User,UserReport>(obj,userreport);
    	}
    public void timed_handle_job(String[] cmd){
    	boolean found= false;
    	User pos=null;
    	TrieNode<Project> node=project.search(cmd[2]);
    	if(node!=null) {
    		TrieNode<User> u= user1.search(cmd[3]);
    		if(u==null) {
    		}
    		else {
    			found=true;
    			pos=u.getValue();
    		}
        	if(found==false) {
        	}
        	else {
        	Project pro= node.getValue();
        	Job job1= new Job(cmd[1],pro,pos,Integer.parseInt(cmd[4]),globaltime);
        	job.insert(job1);
        	tempjob.insert(job1.name,job1);
        	pro.joblist.add(job1);
        	pos.joblist.add(job1);
        	}
        	}
    	else{
    	}
    }
    public void timed_handle_project(String[] cmd){
    	Project project1= new Project(cmd[1],Integer.parseInt(cmd[3]),Integer.parseInt(cmd[2]));
    	project.insert(cmd[1],project1);
    	}
    public void timed_run_to_completion(){
    	while(job.stulist.size()>0) {
			Job pos= job.extractMax();
	    	if(pos.project.budget>=pos.runtime) {
	    		pos.user.pair.second.consumed+=pos.runtime;
	    		count++;
	    		pos.status="COMPLETED";
	    		globaltime+=pos.runtime;
	    		pos.completedtime=globaltime;
	    		pos.project.budget-=pos.runtime;
	    		pos.user.latestruntime=globaltime;
	    		pos.project.fjoblist.add(pos);
	    		pos.user.fjoblist.add(pos);
	    		finishedjobs.add(pos);
	    		if(job.stulist.size()==0) {
	    		}
	    		else {
	    		}
	    		}
	    	else {
    		projectjobs.insert(pos.project.name, pos);
    		pos.project.ufjoblist.add(pos);
    		pos.user.ufjoblist.add(pos);
    		if(job.stulist.size()==0) {
    		}
	    	}
	   
		}
    		}
   
    public void inorder(RedBlackNode<String,Job> node, int priority) {
    	if (node.key==null) 
            return;
        inorder(node.left,priority);
        if(priority==-1) {
        	while(node.object.size()>0) {
        		job.insert(node.object.remove());
        	}
        	while(job.stulist.size()>0) {
        		Job j= job.extractMax();
        		if(unfinished.isEmpty()==true) {
        			unfinished.add(j);
        		}
        		else {
        			unfinished.add(j);
        			int index= unfinished.size()-1;
        			while(index>0) {
        				Job j1=unfinished.get(index-1);
        				if(j1.priority>j.priority) {
        					break;
        				}
        				else if(j1.priority<j.priority) {
        					unfinished.set(index-1,j);
        					unfinished.set(index, j1);
        					index-=1;
        				}
        				else if(j1.priority==j.priority&&j1.project.name.equals(j.project.name)) {
        					if(j1.actualtime>j.actualtime) {
        						unfinished.set(index-1,j);
	        					unfinished.set(index, j1);
	        					index-=1;
        					}
        					else {
        						break;
        					}
        				}
        				else if(j1.priority==j.priority&&!j1.project.name.equals(j.project.name)) {
        					if(j1.project.actualtime>j.project.actualtime) {
        						unfinished.set(index-1,j);
	        					unfinished.set(index, j1);
	        					index-=1;
        					}
        					else {
        						break;
        					}
        				}
        			}
        		}
        	}
        	}
        else {
        	if(node.object.size()>0) {
        		if(project.search(node.key).getValue().priority>=priority) {
        			Iterator<Job> itr= node.object.iterator();
        			while(itr.hasNext()) {
        				Job job=  itr.next();
        				JobReport nr=
        						new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
        				tempreport.add(nr);
        				
        			}
        		}
        		
        	}
        }
        inorder(node.right,priority);
        }

    @Override
    public ArrayList<JobReport_> timed_report(String[] cmd) {
        long qstart_time, qend_time;
        ArrayList<JobReport_> res = null;
        switch (cmd[0]) {
            case "NEW_PROJECT":
                qstart_time = System.nanoTime();
                res = handle_new_project(cmd);
                qend_time = System.nanoTime();
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
            case "NEW_USER":
                qstart_time = System.nanoTime();
                res = handle_new_user(cmd);
                qend_time = System.nanoTime();
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));

                break;
            case "NEW_PROJECTUSER":
                qstart_time = System.nanoTime();
                res = handle_new_projectuser(cmd);
                qend_time = System.nanoTime();
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
            case "NEW_PRIORITY":
                qstart_time = System.nanoTime();
                res = handle_new_priority(cmd[1]);
                qend_time = System.nanoTime();
                System.out.println("Time elapsed (ns): " + (qend_time - qstart_time));
                break;
        }

        return res;
    }

    @Override
    public ArrayList<UserReport_> timed_top_consumer(int top) {
    	Iterator<User> itr= user.iterator();
    	ArrayList<UserReport_> userreport= new ArrayList<UserReport_>();
    	ArrayList<UserReport_> userreport1= new ArrayList<UserReport_>();
    	while(itr.hasNext()) {
    		User u= itr.next();
    		if(userreport.isEmpty()) {
    		userreport.add(u.pair.second);
    		}
    		else {
    			userreport.add(u.pair.second);
    			int index=userreport.size()-1;
    			while(index>0) {
    				UserReport ur= (UserReport)userreport.get(index-1);
    				if(ur.consumed<u.pair.second.consumed) {
    					userreport.set(index-1, u.pair.second);
    					userreport.set(index, ur);
    					index-=1;
    				}
    				else if(ur.consumed==u.pair.second.consumed) {
    					if(ur.user.latestruntime>u.pair.first.latestruntime) {
    						userreport.set(index-1, u.pair.second);
        					userreport.set(index, ur);
        					index-=1;
    					}
    					else {
    						break;
    					}
    				}
    				else {
    					break;
    					}
    				}
    			}
    		}
    	int i=0;
    	while(i<userreport.size()&&i<top) {
    		userreport1.add(userreport.get(i));
    		i++;
    	}
        return userreport1;
    }
    @Override
    public void timed_flush(int waittime) {
    	Iterator<Job> itr= job.stulist.iterator();
    	MaxHeap<Job> unjoblist= new MaxHeap<Job>();
    	MaxHeap<Job> heap= new MaxHeap<Job>();
    	while(itr.hasNext()) {
    		Job j=itr.next();
    		if((globaltime-j.arrivaltime)>=waittime) {
    			unjoblist.insert(j);
    		}
    		else {
    			heap.insert(j);
    		}
    	}
    	job=heap;
    	while(unjoblist.stulist.size()>0) {
    		Job pos= unjoblist.extractMax();
    		if(pos.runtime<=pos.project.budget) {
    			pos.user.pair.second.consumed+=pos.runtime;
        		count++;
        		pos.status="COMPLETED";
        		globaltime+=pos.runtime;
        		pos.completedtime=globaltime;
        		pos.project.budget-=pos.runtime;
        		pos.user.latestruntime=globaltime;
        		pos.project.fjoblist.add(pos);
        		pos.user.fjoblist.add(pos);
        		finishedjobs.add(pos);
    		}
    		else {
    			job.insert(pos);
    		}
    	}
    	}
    

    private ArrayList<JobReport_> handle_new_priority(String s) {
    	tempreport.clear();
    	inorder(projectjobs.root,Integer.parseInt(s));
    	Iterator<Job> itr= job.stulist.iterator();
    	while(itr.hasNext()) {
    		Job job= itr.next();
    		if(job.priority>=Integer.parseInt(s)) {
    			JobReport nr= 
    					new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
    			tempreport.add(nr);
    		}
    	}
        return tempreport;
    }

    private ArrayList<JobReport_> handle_new_projectuser(String[] cmd) {
    	ArrayList<JobReport_> jobreport= new ArrayList<JobReport_>();
    	TrieNode<Project> pos= project.search(cmd[1]);
    	if(pos==null) {
    		return jobreport;
    	}
    	User pos1=null;
    	boolean found=false;
    	TrieNode<User> u= user1.search(cmd[2]);
		if(u==null) {
			return jobreport;
		}
		else {
			found=true;
			pos1=u.getValue();
		}

    	Iterator<Job> itr= pos.getValue().fjoblist.iterator();
    	while(itr.hasNext()) {
    		Job job =itr.next();
    		if(job.user.name.equals(cmd[2])&&job.arrivaltime>=Integer.parseInt(cmd[3]) &&job.arrivaltime<=Integer.parseInt(cmd[4])) {
    		JobReport newreport= new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
    		jobreport.add(newreport);
    		}
    	}
    	Iterator<Job> itr1= pos.getValue().joblist.iterator();
    	while(itr1.hasNext()) {
    		Job job =itr1.next();
    		if(job.status.equals("REQUESTED")&&job.user.name.equals(cmd[2])&&job.arrivaltime>=Integer.parseInt(cmd[3]) &&job.arrivaltime<=Integer.parseInt(cmd[4])) {
    		JobReport newreport= new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
    		jobreport.add(newreport);
    		int index= jobreport.size()-1;
    		while(index>0) {
    			JobReport jr= (JobReport)jobreport.get(index-1);
    			if(jr.actualtime>newreport.actualtime) {
    				jobreport.set(index-1, newreport);
    				jobreport.set(index, jr);
    				index-=1;
    			}
    			else {
    				break;
    			}
    		}
    		}
    	}
    	
        return jobreport;
    }

    private ArrayList<JobReport_> handle_new_user(String[] cmd) {
    	ArrayList<JobReport_> jobreport= new ArrayList<JobReport_>();
    	User pos=null;
    	boolean found=false;
    	TrieNode<User> u= user1.search(cmd[1]);
		if(u==null) {
			return jobreport;
		}
		else {
			found=true;
			pos=u.getValue();
		}
    	if(found==true) {
    	Iterator<Job> iter= pos.joblist.iterator();
    	while(iter.hasNext()) {
    		Job job =iter.next();
    		if(job.arrivaltime>=Integer.parseInt(cmd[2]) &&job.arrivaltime<=Integer.parseInt(cmd[3])) {
    		JobReport newreport= new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
    		jobreport.add(newreport);
    		}
    		}
    	}
        return jobreport;
        }

    private ArrayList<JobReport_> handle_new_project(String[] cmd) {
    	ArrayList<JobReport_> jobreport= new ArrayList<JobReport_>();
    	TrieNode<Project> pos= project.search(cmd[1]);
    	if(pos==null) {
    		return jobreport;
    	}
    	else {
    		Iterator<Job> itr= pos.getValue().joblist.iterator();
    	while(itr.hasNext()) {
    		Job job =itr.next();
    		if(job.arrivaltime>=Integer.parseInt(cmd[2]) &&job.arrivaltime<=Integer.parseInt(cmd[3])) {
    		JobReport newreport= new JobReport(job,job.user,job.project,job.runtime,job.arrivaltime,job.completedtime,job.actualtime);
    		jobreport.add(newreport);
    		}
    	}
    	}
    	return jobreport;
    }




    public void schedule() {
            execute_a_job();
    }

    public void run_to_completion() {
    	System.out.println("Running code");
    	System.out.println("Remaining jobs: "+job.stulist.size());
    		while(job.stulist.size()>0) {
    			Job pos= job.extractMax();
    	    	System.out.println("Executing: "+pos.name+" from: "+pos.project.name);
    	    	if(pos.project.budget>=pos.runtime) {
    	    		pos.user.pair.second.consumed+=pos.runtime;
    	    		count++;
    	    		pos.status="COMPLETED";
    	    		globaltime+=pos.runtime;
    	    		pos.completedtime=globaltime;
    	    		pos.project.budget-=pos.runtime;
    	    		pos.user.latestruntime=globaltime;
    	    		pos.project.fjoblist.add(pos);
    	    		pos.user.fjoblist.add(pos);
    	    		System.out.println("Project: "+pos.project.name+" budget remaining: "+pos.project.budget);
    	    		finishedjobs.add(pos);
    	    		if(job.stulist.size()==0) {
    	    			System.out.println("System execution completed");
    	    		}
    	    		else {
    	    			System.out.println("System execution completed");
    	    			System.out.println("Running code");
        	        	System.out.println("Remaining jobs: "+job.stulist.size());
    	    		}
    	    		}
    	    	else {
    	    	System.out.println("Un-sufficient budget.");
        		projectjobs.insert(pos.project.name, pos);
        		pos.project.ufjoblist.add(pos);
        		pos.user.ufjoblist.add(pos);
        		if(job.stulist.size()==0) {
        			System.out.println("System execution completed");
        		}
    	    	}
    	   
    		}
    }

    public void print_stats() {
    	System.out.println("--------------STATS---------------");
    	System.out.println("Total jobs done: "+ count);
    	while(finishedjobs.size()>0) {
    		System.out.println(finishedjobs.remove().toString());
    	}
    	System.out.println("------------------------");
    	System.out.println("Unfinished jobs: ");
    	inorder(projectjobs.root,-1);
    	int size=unfinished.size();
    	while(unfinished.size()>0) {
    		System.out.println(unfinished.remove(0).toString());
    	}
    	System.out.println("Total unfinished jobs: "+size);
    	System.out.println("--------------STATS DONE---------------");


    }

    public void handle_add(String[] cmd) {
    	System.out.println("ADDING Budget");
    	TrieNode<Project> pos= project.search(cmd[1]);
    	if(pos!=null) {
    	pos.getValue().budget+=Integer.parseInt(cmd[2]);
    	RedBlackNode<String,Job> rbnode=projectjobs.search(cmd[1]);
    	if(rbnode==null) {
    		return;
    		}
    	else {
    		while(rbnode.object.size()>0) {
    			Job j=rbnode.object.remove();
    			job.insert(j);
    			j.project.ufjoblist.remove(j);
        		j.user.ufjoblist.remove(j);
    			}
    	}
    	}
    	else {
    		System.out.println("No such project exists: "+cmd[1]);
    	}
    	}

    public void handle_empty_line() {
       schedule();
    }


    public void handle_query(String key) {
    	System.out.println("Querying");
    	System.out.print(key+":"+" ");
    	TrieNode<Job> pos=tempjob.search(key);
    	 if(pos==null){
    	 	System.out.println("NO SUCH JOB");
    	 }
    	 else{
    	 	if(pos.getValue().status.equalsIgnoreCase("Requested")) {
    			System.out.println("NOT FINISHED");
    		}
    			else {
    				System.out.println("COMPLETED");
    			}
    	 }
    	 }

    public void handle_user(String name) {
    	System.out.println("Creating user");
    	User obj= new User(name);
    	user.add(obj);
    	user1.insert(name, obj);
    	UserReport userreport= new UserReport(obj);
    	obj.pair= new Pair<User,UserReport>(obj,userreport);
    	}

    public void handle_job(String[] cmd) {
    	System.out.println("Creating job");
    	boolean found= false;
    	User pos=null;
    	TrieNode<Project> node=project.search(cmd[2]);
    	if(node!=null) {
    		TrieNode<User> u= user1.search(cmd[3]);
    		if(u==null) {
    		}
    		else {
    			found=true;
    			pos=u.getValue();
    		}
        	if(found==false) {
        		System.out.println("No such user exists: "+cmd[3]);
        	}
        	else {
        	Project pro= node.getValue();
        	Job job1= new Job(cmd[1],pro,pos,Integer.parseInt(cmd[4]),globaltime);
        	job.insert(job1);
        	tempjob.insert(job1.name,job1);
        	pro.joblist.add(job1);
        	pos.joblist.add(job1);
        	}
        	}
    	else{
    		System.out.println("No such project exists. "+cmd[2]);
    	}

    }

    public void handle_project(String[] cmd) {
    	System.out.println("Creating project");
    	Project project1= new Project(cmd[1],Integer.parseInt(cmd[3]),Integer.parseInt(cmd[2]));
    	project.insert(cmd[1],project1);
    	}

    public void execute_a_job() {
    	System.out.println("Running code");
    	System.out.println("Remaining jobs: "+job.stulist.size());
    	if(job.stulist.size()>0) {
    	Job pos= job.extractMax();
    	System.out.println("Executing: "+pos.name+" from: "+pos.project.name);
    	if(pos.project.budget>=pos.runtime) {
    		pos.user.pair.second.consumed+=pos.runtime;
    		count++;
    		pos.status="COMPLETED";
    		globaltime+=pos.runtime;
    		pos.completedtime=globaltime;
    		pos.project.budget-=pos.runtime;
    		pos.user.latestruntime=globaltime;
    		pos.project.fjoblist.add(pos);
    		pos.user.fjoblist.add(pos);
    		System.out.println("Project: "+pos.project.name+" budget remaining: "+pos.project.budget);
    		finishedjobs.add(pos);
    		System.out.println("Execution cycle completed");
    		}
    	else {
    		boolean found= false;
    		System.out.println("Un-sufficient budget.");
    		projectjobs.insert(pos.project.name, pos);
    		pos.project.ufjoblist.add(pos);
    		pos.user.ufjoblist.add(pos);
    		while(job.stulist.size()>0&&found==false) {
    			pos= job.extractMax();
    	    	System.out.println("Executing: "+pos.name+" from: "+pos.project.name);
    	    	if(pos.project.budget>=pos.runtime) {
    	    		pos.user.pair.second.consumed+=pos.runtime;
    	    		count++;
    	    		found=true;
    	    		pos.status="COMPLETED";
    	    		globaltime+=pos.runtime;
    	    		pos.completedtime=globaltime;
    	    		pos.user.latestruntime=globaltime;
    	    		pos.project.budget-=pos.runtime;
    	    		pos.project.fjoblist.add(pos);
    	    		pos.user.fjoblist.add(pos);
    	    		System.out.println("Project: "+pos.project.name+" budget remaining: "+pos.project.budget);
    	    		finishedjobs.add(pos);
    	    		System.out.println("Execution cycle completed");
    	    		}
    	    	else {
    	    	System.out.println("Un-sufficient budget.");
        		projectjobs.insert(pos.project.name, pos);
        		pos.project.ufjoblist.add(pos);
        		pos.user.ufjoblist.add(pos);
    	    	}
    		}
    		if(found==false) {
    			System.out.println("Execution cycle completed");
    		}
    	}
    	}
    }
}
