package ProjectManagement;

public class Job implements Comparable<Job> {
	String name;
	Project project;
	int priority;
	User user;
	int arrivaltime;
	long actualtime;
	int runtime;
	int completedtime;
	String status;
	Job(String name,Project project,User user,int runtime, int arrivaltime ){

		this.name=name;
		this.project=project;
		this.user=user;
		this.runtime=runtime;
		this.completedtime=0;
		this.arrivaltime=arrivaltime;
		this.status= "REQUESTED";
		this.priority= project.priority;
		this.actualtime=System.nanoTime();
	}
	public String toString() {
		if(this.completedtime!=0)
			return "Job{user='"+this.user.name+"', project='"+this.project.name+"', jobstatus="+this.status+", execution_time="+this.runtime+", end_time="+this.completedtime+", name='"+this.name+"'}";
		else
			return "Job{user='"+this.user.name+"', project='"+this.project.name+"', jobstatus="+this.status+", execution_time="+this.runtime+", end_time=null, name='"+this.name+"'}";
			
	}

    @Override
    public int compareTo(Job job) {
    	if(this.priority!=job.priority) {
    		return this.priority- job.priority;
    	}
    	else {
    	if(this.actualtime<job.actualtime) {
    		return 1;
    	}
    	else {
    		return -1;
    	}
    	}
    }
}