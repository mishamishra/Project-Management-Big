package ProjectManagement;

public class UserReport implements UserReport_ {
	User user;
	int consumed;
	UserReport(User user){
		this.user=user;
		this.consumed=0;
	}
	 public String user() {
		 return this.user.name;
	 }
	 public   int    consumed() {
		   return this.consumed;
		   
	   }
	   public String toString() {
		   return "UserReport{user="+this.user.name+", consumed="+this.consumed+"}";
	   }

}
