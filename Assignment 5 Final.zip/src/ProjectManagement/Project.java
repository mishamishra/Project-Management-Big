package ProjectManagement;
import java.util.LinkedList;

public class Project {
	String name;
	int budget;
	int priority;
	long actualtime;
	LinkedList<Job> fjoblist= new LinkedList<Job>();
	LinkedList<Job> ufjoblist= new LinkedList<Job>();
	LinkedList<Job> joblist= new LinkedList<Job>();
	Project(String name,int budget,int priority){
		this.name= name;
		this.budget=budget;
		this.priority=priority;
		this.actualtime= System.nanoTime();
	}


}
