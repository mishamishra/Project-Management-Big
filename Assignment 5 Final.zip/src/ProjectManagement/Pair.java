package ProjectManagement;

public class Pair<X,Y>{
	X first;
	Y second;
	Pair(X f, Y s){
		first=f;
		second=s;
	}
	X getfirst() {
		return first;
	}
	Y getsecond() {
		return second;
	}
	

}

