package ProjectManagement;
import java.util.LinkedList;

public class User  {
	String name;
	Pair<User,UserReport> pair;
	int latestruntime;
	LinkedList<Job> fjoblist= new LinkedList<Job>();
	LinkedList<Job> ufjoblist= new LinkedList<Job>();
	LinkedList<Job> joblist= new LinkedList<Job>();
	User(String name){
		this.name=name;
	}
}
