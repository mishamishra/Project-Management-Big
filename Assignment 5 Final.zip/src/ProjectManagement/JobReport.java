package ProjectManagement;

public class JobReport implements JobReport_ {
	Job job;
	User user;
	Project project;
	int budget;
	int arrival_time;
	long actualtime;
	int completion_time;
	JobReport(Job job,User user, Project project, int budget, int arrival_time, int completion_time, long actualtime){
		this.job=job;
		this.user=user;
		this.project=project;
		this.budget=budget;
		this.arrival_time=arrival_time;
		this.completion_time= completion_time;
		this.actualtime=actualtime;
		
	}
	   public String user() {
		   return this.user.name;
	   }
	   public String project_name() {
		   return this.project.name;
	   }
	   public int budget() {
		   return this.budget;
	   }
	   public int arrival_time() {
		   return this.arrival_time;
	   }
	   public int completion_time(){
		   return this.completion_time;
	   }
	   public String toString() {
		   return "JobReport{user='"+this.user.name+"', project='"+this.project.name+"', jobstatus='"+this.job.status+"', "
		   		+ "executiontime="+this.budget+", start_time="+this.arrival_time+", end_time="+this.completion_time+", priority="+this.job.priority+", name="+this.job.name+"}";
	   }
}
