package RedBlack;
public class RBTree<T extends Comparable, E> implements RBTreeInterface<T, E>  {
    public final RedBlackNode nullnode = new RedBlackNode(null); 
    public RedBlackNode root = nullnode;
    public RedBlackNode temp = root;
    public void updatetemp() {
		temp=root;
}
    private void makeTree(RedBlackNode node) {
        while (node.parent.color=='R') {
            RedBlackNode uncle = nullnode;
            if (node.parent.equals(node.parent.parent.left)) {
                uncle = node.parent.parent.right;

                if (!uncle.equals(nullnode) && uncle.color == 'R') {
                    node.parent.color = 'B';
                    uncle.color = 'B';
                    node.parent.parent.color = 'R';
                    node = node.parent.parent;
                    continue;
                } 
                if (node.equals(node.parent.right)) {
                    node = node.parent;
                    rotateLeft(node);
                } 
                node.parent.color = 'B';
                node.parent.parent.color = 'R';
                rotateRight(node.parent.parent);
            } else {
                uncle = node.parent.parent.left;
                 if (!uncle.equals(nullnode) && uncle.color == 'R') {
                    node.parent.color = 'B';
                    uncle.color = 'B';
                    node.parent.parent.color = 'R';
                    node = node.parent.parent;
                    continue;
                }
                if (node.equals(node.parent.left)) {
                    node = node.parent;
                    rotateRight(node);
                }
                node.parent.color = 'B';
                node.parent.parent.color = 'R';
                rotateLeft(node.parent.parent);
            }
        }
        root.color = 'B';
    }
    
    void rotateLeft(RedBlackNode node) {
        if (!node.parent.equals(nullnode)) {
            if (node.equals(node.parent.left)) {
                node.parent.left = node.right;
            } else {
                node.parent.right = node.right;
            }
            node.right.parent = node.parent;
            node.parent = node.right;
            if (!node.right.left.equals(nullnode)) {
                node.right.left.parent = node;
            }
            node.right = node.right.left;
            node.parent.left = node;
        } else {
            RedBlackNode right = root.right;
            root.right = right.left;
            right.left.parent = root;
            root.parent = right;
            right.left = root;
            right.parent = nullnode;
            root = right;
        }
    }

    void rotateRight(RedBlackNode node) {
        if (!node.parent.equals(nullnode)) {
            if (node.equals(node.parent.left)) {
                node.parent.left = node.left;
            } else {
                node.parent.right = node.left;
            }

            node.left.parent = node.parent;
            node.parent = node.left;
            if (!node.left.right.equals(nullnode)) {
                node.left.right.parent = node;
            }
            node.left = node.left.right;
            node.parent.right = node;
        } else {
            RedBlackNode left = root.left;
            root.left = root.left.right;
            left.right.parent = root;
            root.parent = left;
            left.right = root;
            left.parent = nullnode;
            root = left;
        }
    }

	@Override
    public void insert(T key, E value) {
			RedBlackNode temp = root;
	        if (root.equals(nullnode)) {
	        	root=new RedBlackNode(key);
	        	root.color='B';
	        	root.parent=nullnode;
	        	root.left=nullnode;
	        	root.right=nullnode;
	        	root.object.add(value);
	        } 
	        else {
	            while (true) {
	            	
	                if (temp.compareTo(key)>0) {
	                	if (temp.left.equals(nullnode)) {
	                		RedBlackNode pos= new RedBlackNode(key);
	        	            pos.color = 'R';
	        	            pos.object.add(value);
	                        temp.left = pos;
	                        pos.parent = temp;
	                        pos.left=nullnode;
	                        pos.right=nullnode;
	                        makeTree(pos);
	                        break;
	                    } else {
	                        temp = temp.left;
	                    }
	                } else if (temp.compareTo(key)<0) {
	                    if (temp.right.equals(nullnode)) {
	                    	RedBlackNode pos= new RedBlackNode(key);
	        	            pos.color = 'R';
	        	            pos.object.add(value);
	                        temp.right = pos;
	                        pos.parent = temp;
	                        pos.left=nullnode;
	                        pos.right=nullnode;
	                        makeTree(pos);
	                        break;
	                    } else {
	                        temp = temp.right;
	                    }
	                }
	                else {
	                	temp.object.add(value);
	                	break;
	                }
	            }
	            
	        }
	        this.temp=root;
	    }
	

   
    @Override
    public RedBlackNode<T, E> search(T key) {
            if (root.equals(nullnode)) {
                return null;
            }
            if (temp.compareTo(key)>0) {
                if (!temp.left.equals(nullnode)) {
                	temp=temp.left;
                    return search(key);
                }
                else {
    				updatetemp();
    				RedBlackNode pos= new RedBlackNode(null);
    				pos.object=null;
    				return pos;
    			}
            } 
            else if (temp.compareTo(key)<0) {
                if (!temp.right.equals(nullnode)) {
                	temp=temp.right;
                    return search(key);
                }
                else {
    				updatetemp();
    				RedBlackNode pos= new RedBlackNode(null);
    				pos.object=null;
    				return pos;
    			}
            } 
            else {
            	RedBlackNode pos= temp;
            	updatetemp();
                return pos;
            }
        }
    }