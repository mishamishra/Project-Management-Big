package RedBlack;

import Util.RBNodeInterface;

import java.util.LinkedList;

public class RedBlackNode<T extends Comparable, E> implements RBNodeInterface<E> {
	char color= 'B';
	 public RedBlackNode left=null;
	 public RedBlackNode right=null;
	 RedBlackNode parent=null;
	 public T key;
	 public LinkedList<E> object = new LinkedList<E>();
	 public int compareTo(T key) {
		 return this.key.compareTo(key);
	 }
	 RedBlackNode(T key){
		 this.key= key;
		 }


    @Override
    public E getValue() {
        return null;
    }

    @Override
    public LinkedList<E> getValues() {
        return object;
    }
}
