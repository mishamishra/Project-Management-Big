package PriorityQueue;
import java.util.ArrayList;
public class MaxHeap<T extends Comparable> implements PriorityQueueInterface<T> {
	public ArrayList<T> stulist= new ArrayList<T>();
	
    @Override
    public void insert(T element) {
    	if(stulist.isEmpty()) {
    	stulist.add(element);
    	}
    	else {
    		stulist.add(element);
    	    	}
    		int index= stulist.size()-1;
    		while(index!=0) {
    			if(stulist.get((index-1)/2).compareTo(element)<0) {
    				stulist.set(index,stulist.get((index-1)/2));
    				stulist.set((index-1)/2, element);
    				index=(index-1)/2;
    			}
    			else {
    				break;
    			}
    		}
    	}
  
    @Override
    public T extractMax() {
        	 if(stulist.size()==2) {
        		T s1=stulist.get(1);
    			T s3=stulist.get(0);
        		if(s1.compareTo(s3)>0) {
        				stulist.set(1,s3);
        				stulist.set(0, s1);
        			}
        		}
        	if(!stulist.isEmpty()) {
        		T pop= stulist.get(0);
        		stulist.set(0,stulist.get(stulist.size()-1));
    			stulist.remove(stulist.size()-1);
    			int i=0;
    			while((2*i)+1<stulist.size()&&(2*i)+2<stulist.size()) {
    				T s1=stulist.get((2*i)+1);
    				T s2=stulist.get((2*i)+2);
    				T s3=stulist.get(i);
    				if(s3.compareTo(s1)>0&&s3.compareTo(s2)>0) {
    					break;
    				}
    				else if(s1.compareTo(s3)>s2.compareTo(s3)) {
    					stulist.set((2*i)+1,s3);
	    				stulist.set(i, s1);
	    				i= (2*i)+1;
    				}
    				else if(s1.compareTo(s3)<s2.compareTo(s3)) {
    					stulist.set((2*i)+2,s3);
	    				stulist.set(i, s2);
	    				i= (2*i)+2;
    				}
    				else if(s1.compareTo(s3)==s2.compareTo(s3)) {
    					if(s1.compareTo(s2)>0) {
    						stulist.set((2*i)+1,s3);
    	    				stulist.set(i, s1);
    	    				i= (2*i)+1;
    					}
    					else {
    						stulist.set((2*i)+2,s3);
    	    				stulist.set(i, s2);
    	    				i= (2*i)+2;
    					}
    				}
    			}
    			if((2*i)+1==stulist.size()-1) {
    			if(stulist.get((2*i)+1).compareTo(stulist.get(i))>0) {
    				T pop1= stulist.get((2*i)+1);
					stulist.set((2*i)+1,stulist.get(i));
    				stulist.set(i, pop1);
    			}
    			}
    			return pop;
        	}
    			
        	else {
        		return null;
        	}
    }
}

