package PriorityQueue;

public class Student implements Comparable<Student> {
    private String name;
    private Integer marks;
    private long actualtime;
    public Student(String trim, int parseInt) {
    	this.name=trim;
    	this.marks=parseInt;
    	this.actualtime=System.nanoTime();
    }


    @Override
    public int compareTo(Student student) {
    	if(this.marks!=student.marks) {
        return this.marks-student.marks;
    	}
    	else {
    		if(this.actualtime<student.actualtime) {
        		return 1;
        	}
        	else {
        		return -1;
        	}
    	}
    }

    public String getName() {
        return name;
    }
    public String toString() {
    	return "Student{name='"+this.name+"', marks="+this.marks+"}";
    }
}
